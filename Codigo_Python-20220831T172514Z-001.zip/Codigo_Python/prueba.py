def run():
    nombre = 'Ian'
    print(nombre * 2)


if __name__ == '__main__':
    run()