# def imprimir_mensaje():
#     print("mensaje especial: ")
#     print("¡Estoy aprendiendo a usar funciones!")


# imprimir_mensaje()
# imprimir_mensaje()
# imprimir_mensaje()

# opcion = input("Elige una opcion (1, 2, 3): ")

# def conversacion(opcion):
#     print("Hola")
#     print("¿Como estas?")
#     print("Elegiste la opcion " + opcion)
#     print("Adios")

# if opcion == '1':
#     conversacion(opcion)
# elif opcion == '2':
#     conversacion(opcion)
# elif opcion == '3':
#     conversacion(opcion)
# else:
#     print("Ingresa una opcion correcta")

def suma(a, b):
    print("Se suman dos numeros")
    resultado = a + b 
    return resultado

sumatoria = suma(1, 4)
print(sumatoria)