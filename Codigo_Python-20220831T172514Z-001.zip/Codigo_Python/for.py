def run():
    for contador in range(1, 1001):
        print(contador)


if __name__ == '__main__':
    run()