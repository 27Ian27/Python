# edad = int(input("Escribe tu edad: "))

# if edad > 17:
#     print("Eres mayor de edad")
# else:
#     print("Eres menor de edad")

estado = str(input("¿Estas bien? "))

if estado == "si":
    print("Cuentas conmigo <3")
elif estado == "no":
    print("Cuentas conmigo al doble <3 <3 <3")
else:
    print("No importa, siempre estare para ti mi niña chiquita")